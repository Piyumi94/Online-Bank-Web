package com.javatodev.finance.model;

public enum AccountStatus {
    PENDING,ACTIVE,DORMANT,BLOCKED
}
