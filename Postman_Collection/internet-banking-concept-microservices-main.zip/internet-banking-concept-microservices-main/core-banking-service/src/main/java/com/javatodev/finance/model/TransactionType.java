package com.javatodev.finance.model;

public enum TransactionType {

    FUND_TRANSFER, UTILITY_PAYMENT

}
