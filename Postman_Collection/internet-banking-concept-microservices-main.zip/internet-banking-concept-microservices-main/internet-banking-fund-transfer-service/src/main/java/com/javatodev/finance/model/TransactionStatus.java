package com.javatodev.finance.model;

public enum TransactionStatus {
    PENDING, PROCESSING, SUCCESS, FAILED
}
