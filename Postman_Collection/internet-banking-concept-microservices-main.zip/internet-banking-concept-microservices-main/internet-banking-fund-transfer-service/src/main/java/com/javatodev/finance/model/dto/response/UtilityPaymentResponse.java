package com.javatodev.finance.model.dto.response;

public class UtilityPaymentResponse {
}
