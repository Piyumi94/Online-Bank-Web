package com.javatodev.finance.model.dto;

public enum Status {
    PENDING, APPROVED, DISABLED, BLACKLIST
}
