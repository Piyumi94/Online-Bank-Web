package com.javatodev.finance.model.dto;

import lombok.Data;

@Data
public class UserUpdateRequest {
    private Status status;
}
